conmanv3

Contact Management testing

Aplikasi ini hanya testing dengan menggunakan vue3 baik BE dan FE

    data json
    Backend
    Frontend

Download

setelah di download

    pindahkan ke folder testing anda
    cek di dalam folder harusnya ada 2 folder ( be dan fe)
    jalankan code . apabila dg visual studio

Clone Repo

copy link
Running

buka dua terminal untuk (fe dan be)

untuk be ketik npm start untuk fe ketik npm run dev
Mohon maaf baru mulai mencoba vue3

so untuk edit belum bisa
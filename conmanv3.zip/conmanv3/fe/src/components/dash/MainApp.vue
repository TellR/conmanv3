    <template>
     <div id="wrapper" class="animate">
        <div class="container-fluid">
          <div class="row">
            <div class="col">
              <div class="card">
                <div class="card-body">
                  <h5 class="card-title">Vue 3</h5>
                  <h6 class="card-subtitle mb-2 text-muted">Habibur</h6>
                  <p class="card-text">Ternyata Vue Asyik juga</p>
                </div>
              </div>
            </div>
            <div class="col">
              <div class="card">
                <div class="card-body">
                  <h5 class="card-title">Vuejs</h5>
                  <h6 class="card-subtitle mb-2 text-muted">Rahman</h6>
                  <p class="card-text">Visi: Gak kemana mana cuma ada dimana mana</p>
                </div>
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col">
              <div class="card">
                <div class="card-body">
                  <h5 class="card-title">Harapan</h5>
                  <span> Sukses Dunia Akhirat </span>
                </div>
              </div>
            </div>
            <div class="col">
              <div class="card">
                <div class="card-body">
                  <h5 class="card-title">DOA</h5>
                  <span> Semoga Hidup Makin Berkah dan Barokah </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </template>